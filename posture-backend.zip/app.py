import os
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import cv2
import numpy as np
import mediapipe as mp
import base64
import io
import math
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageFont
import matplotlib
matplotlib.use('Agg')

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# Initialize MediaPipe Pose
mp_pose = mp.solutions.pose
pose = mp_pose.Pose(static_image_mode=True, model_complexity=2, enable_segmentation=False, min_detection_confidence=0.3)
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

# Define the upload folder and results folder
UPLOAD_FOLDER = 'uploads'
RESULTS_FOLDER = 'results'
for folder in [UPLOAD_FOLDER, RESULTS_FOLDER]:
    if not os.path.exists(folder):
        os.makedirs(folder)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RESULTS_FOLDER'] = RESULTS_FOLDER

# Serve static files from results folder
@app.route('/results/<path:filename>')
def serve_result(filename):
    return send_from_directory(app.config['RESULTS_FOLDER'], filename)

# Helper function to calculate angle between three points
def calculate_angle(a, b, c):
    """
    Calculate the angle between three points (in degrees).
    Points a, b, c are landmark objects with x, y, visibility attributes.
    b is the vertex point.
    Returns angle or None if any landmark is not sufficiently visible.
    """
    # Check visibility
    if a.visibility < 0.5 or b.visibility < 0.5 or c.visibility < 0.5:
        return None
        
    angle_radians = math.atan2(c.y - b.y, c.x - b.x) - math.atan2(a.y - b.y, a.x - b.x)
    angle_degrees = math.degrees(angle_radians)
    
    # Ensure angle is positive
    if angle_degrees < 0:
        angle_degrees += 360
    
    # Convert to the smaller angle (acute or obtuse)
    if angle_degrees > 180:
        angle_degrees = 360 - angle_degrees
        
    return angle_degrees

# Helper function to calculate vertical alignment
def calculate_vertical_alignment(landmarks, image_height, image_width):
    """
    Calculate vertical alignment based on key landmarks.
    Returns alignment offset percentage, side (left/right), or None if landmarks are missing.
    """
    # Get ear and shoulder landmarks
    left_ear = landmarks[mp_pose.PoseLandmark.LEFT_EAR.value]
    right_ear = landmarks[mp_pose.PoseLandmark.RIGHT_EAR.value]
    left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
    right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
    
    # Check visibility
    if (left_ear.visibility < 0.5 or right_ear.visibility < 0.5 or 
        left_shoulder.visibility < 0.5 or right_shoulder.visibility < 0.5):
        return None, None
    
    # Calculate midpoints
    ear_midpoint_x = (left_ear.x + right_ear.x) / 2
    shoulder_midpoint_x = (left_shoulder.x + right_shoulder.x) / 2
    
    # Calculate alignment offset as percentage of image width
    alignment_offset = abs(ear_midpoint_x - shoulder_midpoint_x) * 100
    
    # Determine which side is leaning
    side = "يسار" if ear_midpoint_x < shoulder_midpoint_x else "يمين"
    
    return alignment_offset, side

# Helper function to analyze shoulder tilt
def analyze_shoulder_tilt(landmarks):
    """
    Analyze shoulder tilt and return angle and assessment, or None if landmarks are missing.
    """
    left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
    right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
    
    # Check visibility
    if left_shoulder.visibility < 0.5 or right_shoulder.visibility < 0.5:
        return None, "تعذر تحليل الكتفين - نقاط غير واضحة"
        
    # Calculate shoulder tilt angle
    dx = right_shoulder.x - left_shoulder.x
    dy = right_shoulder.y - left_shoulder.y
    angle = math.degrees(math.atan2(dy, dx))
    
    # Normalize angle to be between -90 and 90
    if angle > 90:
        angle = angle - 180
    elif angle < -90:
        angle = angle + 180
    
    # Assess shoulder tilt
    assessment = ""
    if abs(angle) < 5:
        assessment = "ممتاز - الكتفان متوازيان"
    elif abs(angle) < 10:
        assessment = "جيد - ميل طفيف في الكتفين"
    else:
        higher_side = "الأيسر" if angle > 0 else "الأيمن"
        assessment = f"يحتاج تحسين - ميل واضح في الكتفين، الكتف {higher_side} أعلى"
    
    return abs(angle), assessment

# Helper function to analyze head position
def analyze_head_position(landmarks):
    """
    Analyze head position relative to shoulders and return assessment, or None if landmarks are missing.
    """
    # Get relevant landmarks
    left_ear = landmarks[mp_pose.PoseLandmark.LEFT_EAR.value]
    right_ear = landmarks[mp_pose.PoseLandmark.RIGHT_EAR.value]
    left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
    right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
    
    # Check visibility
    if (left_ear.visibility < 0.5 or right_ear.visibility < 0.5 or 
        left_shoulder.visibility < 0.5 or right_shoulder.visibility < 0.5):
        return None, "تعذر تحليل وضعية الرأس - نقاط غير واضحة"
        
    # Calculate ear midpoint
    ear_midpoint_x = (left_ear.x + right_ear.x) / 2
    
    # Calculate shoulder midpoint
    shoulder_midpoint_x = (left_shoulder.x + right_shoulder.x) / 2
    
    # Calculate forward head position (horizontal distance from ear midpoint to shoulder midpoint)
    # Assuming side view, use X-axis difference
    forward_head_distance = (ear_midpoint_x - shoulder_midpoint_x) * 100  # Positive if head is forward
    
    # Assess head position
    assessment = ""
    if forward_head_distance < 2: # Head aligned or slightly back
        assessment = "ممتاز - وضعية الرأس مثالية"
    elif forward_head_distance < 5:
        assessment = "جيد - وضعية الرأس طبيعية"
    elif forward_head_distance < 10:
        assessment = "متوسط - ميل خفيف للرأس للأمام"
    else:
        assessment = "يحتاج تحسين - الرأس مائل للأمام بشكل واضح (Forward Head Posture)"
    
    return forward_head_distance, assessment

# Helper function to analyze spine alignment
def analyze_spine_alignment(landmarks):
    """
    Analyze spine alignment and return assessment, or None if landmarks are missing.
    """
    # Get relevant landmarks for spine
    left_shoulder = landmarks[mp_pose.PoseLandmark.LEFT_SHOULDER.value]
    right_shoulder = landmarks[mp_pose.PoseLandmark.RIGHT_SHOULDER.value]
    left_hip = landmarks[mp_pose.PoseLandmark.LEFT_HIP.value]
    right_hip = landmarks[mp_pose.PoseLandmark.RIGHT_HIP.value]
    
    # Check visibility
    if (left_shoulder.visibility < 0.5 or right_shoulder.visibility < 0.5 or 
        left_hip.visibility < 0.5 or right_hip.visibility < 0.5):
        return None, "تعذر تحليل استقامة العمود الفقري - نقاط غير واضحة"
        
    shoulder_mid_x = (left_shoulder.x + right_shoulder.x) / 2
    shoulder_mid_y = (left_shoulder.y + right_shoulder.y) / 2
    hip_mid_x = (left_hip.x + right_hip.x) / 2
    hip_mid_y = (left_hip.y + right_hip.y) / 2
    
    # Create virtual points for spine
    spine_top = type("obj", (object,), {"x": shoulder_mid_x, "y": shoulder_mid_y})
    spine_bottom = type("obj", (object,), {"x": hip_mid_x, "y": hip_mid_y})
    
    # Calculate spine angle from vertical
    dx = spine_bottom.x - spine_top.x
    dy = spine_bottom.y - spine_top.y
    if dy == 0: # Avoid division by zero
        spine_angle = 90 if dx != 0 else 0
    else:
        spine_angle = abs(math.degrees(math.atan2(dx, dy)))
    
    # Assess spine alignment
    assessment = ""
    if spine_angle < 3:
        assessment = "ممتاز - العمود الفقري مستقيم تمامًا"
    elif spine_angle < 5:
        assessment = "جيد - استقامة العمود الفقري طبيعية"
    elif spine_angle < 10:
        assessment = "متوسط - انحناء خفيف في العمود الفقري"
    else:
        lean_direction = "اليمين" if dx > 0 else "اليسار"
        assessment = f"يحتاج تحسين - انحناء واضح في العمود الفقري باتجاه {lean_direction}"
    
    return spine_angle, assessment

# Helper function to generate overall posture score
def generate_posture_score(analyses):
    """
    Generate an overall posture score based on individual analyses.
    Handles missing measurements gracefully.
    """
    # Initialize default values
    shoulder_tilt = None
    head_position = None
    spine_angle = None
    
    # Extract scores from analyses if available
    if 'shoulder_tilt' in analyses and 'angle' in analyses['shoulder_tilt'] and analyses['shoulder_tilt']['angle'] is not None:
        shoulder_tilt = analyses['shoulder_tilt']['angle']
    
    if 'head_position' in analyses and 'distance' in analyses['head_position'] and analyses['head_position']['distance'] is not None:
        head_position = analyses['head_position']['distance']
    
    if 'spine_alignment' in analyses and 'angle' in analyses['spine_alignment'] and analyses['spine_alignment']['angle'] is not None:
        spine_angle = analyses['spine_alignment']['angle']
    
    # Check if we have enough data to calculate a score
    if shoulder_tilt is None and head_position is None and spine_angle is None:
        return {
            'score': 0,
            'rating': "تعذر التقييم - بيانات غير كافية"
        }
    
    # Calculate weighted score with available measurements
    weighted_score = 0
    weight_sum = 0
    
    if shoulder_tilt is not None:
        weighted_score += shoulder_tilt * 1.0
        weight_sum += 1.0
    
    if head_position is not None:
        weighted_score += head_position * 2.0
        weight_sum += 2.0
    
    if spine_angle is not None:
        weighted_score += spine_angle * 1.5
        weight_sum += 1.5
    
    # Avoid division by zero
    if weight_sum == 0:
        return {
            'score': 0,
            'rating': "تعذر التقييم - بيانات غير كافية"
        }
    
    # Normalize weighted score by the sum of weights used
    normalized_weighted_score = weighted_score / weight_sum
    
    # Convert to 0-100 scale (higher is better)
    max_bad_score = 20  # Maximum expected bad score per measurement
    score = max(0, 100 - (normalized_weighted_score / max_bad_score * 100))
    score = min(100, score)  # Cap at 100
    
    # Determine rating
    rating = ""
    if score >= 90:
        rating = "ممتاز"
    elif score >= 80:
        rating = "جيد جدًا"
    elif score >= 70:
        rating = "جيد"
    elif score >= 60:
        rating = "متوسط"
    else:
        rating = "يحتاج تحسين"
    
    return {
        'score': round(score),
        'rating': rating
    }

# Helper function to generate recommendations
def generate_recommendations(analyses):
    """
    Generate personalized recommendations based on analyses.
    """
    recommendations = []
    
    # Shoulder recommendations
    if analyses['shoulder_tilt']['angle'] > 10:
        recommendations.append("قم بتمارين تقوية عضلات الكتف والظهر العلوي لتحسين توازن الكتفين.")
        recommendations.append("مارس تمارين الاستطالة للعضلات الصدرية لتقليل شد الكتفين للأمام.")
    
    # Head position recommendations
    if analyses['head_position']['distance'] > 5:
        recommendations.append("قم بتمارين تقوية عضلات الرقبة الخلفية لتحسين وضعية الرأس.")
        recommendations.append("تجنب النظر للأسفل لفترات طويلة أثناء استخدام الهاتف أو الكمبيوتر.")
    
    # Spine alignment recommendations
    if analyses['spine_alignment']['angle'] > 5:
        recommendations.append("مارس تمارين تقوية عضلات البطن والظهر لتحسين استقامة العمود الفقري.")
        recommendations.append("تأكد من جلوسك بشكل صحيح أثناء العمل أو الدراسة، مع دعم أسفل الظهر.")
    
    # General recommendations
    recommendations.append("حافظ على ممارسة تمارين الاستطالة والتقوية بانتظام للحفاظ على وضعية جيدة.")
    recommendations.append("خذ فترات راحة منتظمة من الجلوس أو الوقوف لفترات طويلة.")
    
    return recommendations

@app.route('/analyze', methods=['POST'])
def analyze_image():
    if 'image' not in request.files:
        return jsonify({'error': 'لم يتم توفير ملف صورة'}), 400

    file = request.files['image']

    if file.filename == '':
        return jsonify({'error': 'لم يتم اختيار ملف'}), 400

    if file:
        try:
            # Read image file in memory
            in_memory_file = io.BytesIO()
            file.save(in_memory_file)
            in_memory_file.seek(0)
            image_bytes = np.frombuffer(in_memory_file.read(), np.uint8)
            image = cv2.imdecode(image_bytes, cv2.IMREAD_COLOR)

            if image is None:
                return jsonify({'error': 'تعذر فك ترميز الصورة'}), 400

            # Get image dimensions
            image_height, image_width, _ = image.shape
            
            # Convert the BGR image to RGB for MediaPipe
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            image_rgb.flags.writeable = False

            # Process the image and find pose landmarks
            results = pose.process(image_rgb)
            
            # Create a copy for drawing
            image_rgb.flags.writeable = True
            annotated_image = image_rgb.copy()
            
            # Initialize analysis results
            analyses = {}
            
            if not results.pose_landmarks:
                return jsonify({
                    'error': 'لم يتم اكتشاف أي نقاط للجسم في الصورة. حاول بصورة أوضح أو بوضعية مختلفة.'
                }), 400
            
            # Draw pose landmarks on the image
            mp_drawing.draw_landmarks(
                annotated_image,
                results.pose_landmarks,
                mp_pose.POSE_CONNECTIONS,
                landmark_drawing_spec=mp_drawing_styles.get_default_pose_landmarks_style())
            
            # Get landmarks as a list
            landmarks = results.pose_landmarks.landmark
            
            # Analyze shoulder tilt
            shoulder_tilt_angle, shoulder_assessment = analyze_shoulder_tilt(landmarks)
            analyses['shoulder_tilt'] = {
                'angle': shoulder_tilt_angle,
                'assessment': shoulder_assessment
            }
            
            # Analyze head position
            head_distance, head_assessment = analyze_head_position(landmarks)
            analyses['head_position'] = {
                'distance': head_distance,
                'assessment': head_assessment
            }
            
            # Analyze spine alignment
            spine_angle, spine_assessment = analyze_spine_alignment(landmarks)
            analyses['spine_alignment'] = {
                'angle': spine_angle,
                'assessment': spine_assessment
            }
            
            # Calculate vertical alignment
            alignment_offset, alignment_side = calculate_vertical_alignment(landmarks, image_height, image_width)
            analyses['vertical_alignment'] = {
                'offset': alignment_offset,
                'side': alignment_side,
                'assessment': f"ميل الجسم: {alignment_offset:.1f}% نحو {alignment_side}"
            }
            
            # Generate overall score
            overall_score = generate_posture_score(analyses)
            analyses['overall_score'] = overall_score
            
            # Generate recommendations
            recommendations = generate_recommendations(analyses)
            analyses['recommendations'] = recommendations
            
            # Create visualization with matplotlib
            plt.figure(figsize=(12, 16))
            plt.imshow(annotated_image)
            
            # Draw vertical alignment line
            nose_landmark = landmarks[mp_pose.PoseLandmark.NOSE.value]
            left_ankle = landmarks[mp_pose.PoseLandmark.LEFT_ANKLE.value]
            right_ankle = landmarks[mp_pose.PoseLandmark.RIGHT_ANKLE.value]
            ankle_mid_x = (left_ankle.x + right_ankle.x) / 2
            ankle_mid_y = (left_ankle.y + right_ankle.y) / 2
            
            # Draw ideal vertical line (green)
            plt.plot([ankle_mid_x * image_width, ankle_mid_x * image_width], 
                     [image_height, 0], 'g-', linewidth=2)
            
            # Draw actual alignment line (red)
            plt.plot([ankle_mid_x * image_width, nose_landmark.x * image_width], 
                     [ankle_mid_y * image_height, nose_landmark.y * image_height], 'r-', linewidth=2)
            
            # Add text annotations for measurements
            plt.text(10, 30, f"تقييم الوضعية: {overall_score['rating']} ({overall_score['score']}/100)", 
                     fontsize=12, color='blue', backgroundcolor='white')
            plt.text(10, 60, f"ميل الكتفين: {shoulder_tilt_angle:.1f}°", 
                     fontsize=10, color='black', backgroundcolor='white')
            plt.text(10, 90, f"وضعية الرأس: {head_distance:.1f}%", 
                     fontsize=10, color='black', backgroundcolor='white')
            plt.text(10, 120, f"استقامة العمود الفقري: {spine_angle:.1f}°", 
                     fontsize=10, color='black', backgroundcolor='white')
            
            # Save the visualization
            result_filename = f"posture_analysis_{os.urandom(4).hex()}.jpg"
            result_path = os.path.join(app.config['RESULTS_FOLDER'], result_filename)
            plt.axis('off')
            plt.tight_layout()
            plt.savefig(result_path, bbox_inches='tight')
            plt.close()
            
            # Generate HTML report
            report_html = f"""
            <div class="report-container">
                <h2>تقرير تحليل وضعية الجسم</h2>
                
                <div class="score-section">
                    <h3>التقييم العام</h3>
                    <div class="score-display">
                        <div class="score-circle" style="background: conic-gradient(#4CAF50 0% {overall_score['score']}%, #f0f0f0 {overall_score['score']}% 100%);">
                            <span class="score-text">{overall_score['score']}</span>
                        </div>
                        <div class="score-label">{overall_score['rating']}</div>
                    </div>
                </div>
                
                <div class="analysis-section">
                    <h3>تفاصيل التحليل</h3>
                    <table class="analysis-table">
                        <tr>
                            <th>المنطقة</th>
                            <th>القياس</th>
                            <th>التقييم</th>
                        </tr>
                        <tr>
                            <td>الكتفين</td>
                            <td>{analyses['shoulder_tilt']['angle']:.1f}°</td>
                            <td>{analyses['shoulder_tilt']['assessment']}</td>
                        </tr>
                        <tr>
                            <td>وضعية الرأس</td>
                            <td>{analyses['head_position']['distance']:.1f}%</td>
                            <td>{analyses['head_position']['assessment']}</td>
                        </tr>
                        <tr>
                            <td>العمود الفقري</td>
                            <td>{analyses['spine_alignment']['angle']:.1f}°</td>
                            <td>{analyses['spine_alignment']['assessment']}</td>
                        </tr>
                        <tr>
                            <td>المحاذاة العامة</td>
                            <td>{analyses['vertical_alignment']['offset']:.1f}%</td>
                            <td>{analyses['vertical_alignment']['assessment']}</td>
                        </tr>
                    </table>
                </div>
                
                <div class="recommendations-section">
                    <h3>التوصيات</h3>
                    <ul class="recommendations-list">
            """
            
            for recommendation in recommendations:
                report_html += f"<li>{recommendation}</li>"
            
            report_html += """
                    </ul>
                </div>
                
                <div class="image-section">
                    <h3>الصورة المحللة</h3>
                    <img src="/results/{}" alt="تحليل الوضعية" class="analysis-image">
                </div>
                
                <div class="disclaimer">
                    <p>ملاحظة: هذا التحليل تقريبي ويهدف للتوعية فقط. للحصول على تقييم دقيق، يرجى استشارة أخصائي علاج طبيعي.</p>
                </div>
            </div>
            """.format(result_filename)
            
            # Add CSS for styling the report
            report_css = """
            <style>
                .report-container {
                    font-family: 'Arial', sans-serif;
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: #f9f9f9;
                    border-radius: 10px;
                    box-shadow: 0 0 10px rgba(0,0,0,0.1);
                    direction: rtl;
                }
                
                h2 {
                    color: #2c3e50;
                    text-align: center;
                    border-bottom: 2px solid #3498db;
                    padding-bottom: 10px;
                }
                
                h3 {
                    color: #2980b9;
                    margin-top: 20px;
                }
                
                .score-section {
                    text-align: center;
                    margin: 30px 0;
                }
                
                .score-display {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                }
                
                .score-circle {
                    width: 120px;
                    height: 120px;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin-bottom: 10px;
                    position: relative;
                }
                
                .score-text {
                    font-size: 36px;
                    font-weight: bold;
                    color: #2c3e50;
                }
                
                .score-label {
                    font-size: 24px;
                    font-weight: bold;
                    color: #3498db;
                }
                
                .analysis-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 20px 0;
                }
                
                .analysis-table th, .analysis-table td {
                    padding: 12px;
                    text-align: right;
                    border-bottom: 1px solid #ddd;
                }
                
                .analysis-table th {
                    background-color: #3498db;
                    color: white;
                }
                
                .analysis-table tr:nth-child(even) {
                    background-color: #f2f2f2;
                }
                
                .recommendations-list li {
                    margin-bottom: 10px;
                    line-height: 1.5;
                }
                
                .analysis-image {
                    max-width: 100%;
                    height: auto;
                    border-radius: 5px;
                    margin: 20px 0;
                    display: block;
                    margin-left: auto;
                    margin-right: auto;
                }
                
                .disclaimer {
                    font-size: 12px;
                    color: #7f8c8d;
                    font-style: italic;
                    margin-top: 30px;
                    text-align: center;
                }
            </style>
            """
            
            # Combine CSS and HTML
            full_report = report_css + report_html
            
            # Convert annotated image to base64 for response
            _, buffer = cv2.imencode('.jpg', cv2.cvtColor(annotated_image, cv2.COLOR_RGB2BGR))
            annotated_image_base64 = base64.b64encode(buffer).decode('utf-8')
            
            return jsonify({
                'report': full_report,
                'annotated_image': f"data:image/jpeg;base64,{annotated_image_base64}",
                'result_image_url': f"/results/{result_filename}",
                'analyses': analyses
            })

        except Exception as e:
            print(f"Error processing image: {e}")
            import traceback
            traceback.print_exc()
            return jsonify({'error': f'حدث خطأ أثناء معالجة الصورة: {str(e)}'}), 500

    return jsonify({'error': 'خطأ غير معروف'}), 500

if __name__ == '__main__':
    # Listen on all interfaces, important for deployment/exposure
    app.run(host='0.0.0.0', port=5001, debug=True) # Using port 5001 for backend

